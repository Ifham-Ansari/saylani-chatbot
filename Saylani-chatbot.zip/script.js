const prevButton = document.querySelector('.prev-button');
const nextButton = document.querySelector('.next-button');

prevButton.addEventListener('click', () => {
    // Code to handle previous section
    console.log('Previous section');
});

nextButton.addEventListener('click', () => {
    // Code to handle next section
    console.log('Next section');
});
